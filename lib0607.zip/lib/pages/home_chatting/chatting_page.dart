import 'dart:io'; // File 클래스 사용을 위한 import 추가
import 'package:flutter/foundation.dart'; // debugPrint 사용을 위한 import 추가
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart'; // Import Riverpod
import 'package:tiiun/services/conversation_service.dart'; // Corrected import for ConversationService
import 'package:tiiun/models/conversation_model.dart'; // Import Conversation model
import 'package:tiiun/models/message_model.dart'; // Import Message model
import 'package:tiiun/design_system/colors.dart';
import 'package:tiiun/design_system/typography.dart';
import 'package:tiiun/services/ai_service.dart'; // Import AiService
import 'package:tiiun/utils/error_handler.dart'; // Import ErrorHandler for consistent error handling
import 'package:flutter_svg/flutter_svg.dart'; // Import flutter_svg
import 'package:cached_network_image/cached_network_image.dart'; // 이미지 표시용
import 'package:image_picker/image_picker.dart'; // 이미지 선택용
import 'dart:ui';

// Import the new Modal AnalysisScreen
import 'package:tiiun/pages/home_chatting/analysis_page.dart'; // 새로운 Modal Analysis Screen import
import 'package:tiiun/services/voice_assistant_service.dart'; // VoiceAssistantService 임포트
import 'package:tiiun/services/speech_to_text_service.dart'; // SpeechToTextService 임포트 (SimpleSpeechRecognizer 상태를 받기 위함)
import 'package:tiiun/services/voice_service.dart'; // VoiceService for audio playback
import 'package:tiiun/services/image_service.dart'; // 이미지 서비스 임포트
import 'package:tiiun/services/gpt4o_audio_service.dart'; // 🆕 GPT-4o Audio Service 임포트
import 'package:record/record.dart' as record_pkg; // 🆕 음성 녹음을 위한 패키지
import 'package:path_provider/path_provider.dart'; // 🆕 임시 파일 저장용
import 'package:uuid/uuid.dart'; // 🆕 고유 파일명 생성용

class ChatScreen extends ConsumerStatefulWidget {
  final String? initialMessage;
  final String? conversationId;

  const ChatScreen({
    super.key,
    this.initialMessage,
    this.conversationId,
  });

  @override
  ConsumerState<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends ConsumerState<ChatScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _textFieldFocusNode = FocusNode();

  final ValueNotifier<bool> _hasTextNotifier = ValueNotifier<bool>(false);
  final ValueNotifier<bool> _isRecordingNotifier = ValueNotifier<bool>(false); // 녹음 상태를 위한 ValueNotifier 추가
  final ValueNotifier<String> _currentTranscriptionNotifier = ValueNotifier<String>(''); // 실시간 음성 인식을 위한 ValueNotifier 추가
  final ValueNotifier<bool> _isUploadingImageNotifier = ValueNotifier<bool>(false); // 이미지 업로드 상태 추가
  final ValueNotifier<bool> _isProcessingAudioNotifier = ValueNotifier<bool>(false); // 🆕 오디오 처리 상태 추가

  // 🆕 녹음 관련 변수
  final record_pkg.AudioRecorder _audioRecorder = record_pkg.AudioRecorder();
  final Uuid _uuid = const Uuid();
  String? _currentRecordingPath;


  String? _currentConversationId;
  bool _isLoading = false;
  bool _isTyping = false;

  @override
  void initState() {
    super.initState();
    _currentConversationId = widget.conversationId;

    _messageController.addListener(_onTextChanged);

    if (widget.initialMessage != null && widget.conversationId == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _sendMessage(widget.initialMessage!);
      });
    }
  }

  @override
  void dispose() {
    _messageController.removeListener(_onTextChanged);
    _messageController.dispose();
    _scrollController.dispose();
    _textFieldFocusNode.dispose();
    _hasTextNotifier.dispose();
    _isRecordingNotifier.dispose(); // ValueNotifier dispose 추가
    _currentTranscriptionNotifier.dispose(); // ValueNotifier dispose 추가
    _isUploadingImageNotifier.dispose(); // 이미지 업로드 상태 dispose 추가
    _isProcessingAudioNotifier.dispose(); // 🆕 오디오 처리 상태 dispose 추가
    _audioRecorder.dispose(); // 🆕 녹음기 dispose 추가
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        toolbarHeight: 56,
        backgroundColor: Colors.white,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          padding: const EdgeInsets.fromLTRB(0, 20, 0, 12),
          icon: SvgPicture.asset(
            'assets/icons/functions/back.svg',
            width: 24,
            height: 24,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          Container(
            padding: const EdgeInsets.fromLTRB(0, 20, 20, 12),
            child: GestureDetector(
              onTap: _showAnalysisModal,
              child: SvgPicture.asset(
                'assets/icons/functions/record.svg',
                width: 24,
                height: 24,
              ),
            ),
          )
        ],
      ),
      body: Stack(
        children: [
          // 메인 콘텐츠 (입력창과 겹치도록)
          GestureDetector(
            onTap: _focusTextField,
            child: Column(
              children: [
                Expanded(
                  child: _currentConversationId != null
                      ? _buildMessageList()
                      : _buildEmptyState(),
                ),
                if (_isTyping) _buildTypingIndicator(),
                // 🆕 오디오 처리 인디케이터 추가
                ValueListenableBuilder<bool>(
                  valueListenable: _isProcessingAudioNotifier,
                  builder: (context, isProcessing, child) {
                    if (!isProcessing) return const SizedBox.shrink();
                    return _buildAudioProcessingIndicator();
                  },
                ),
              ],
            ),
          ),

          // 하단 고정 블러 입력창 (주변은 투명, 입력칸만 블러)
          Positioned(
            left: 12,
            right: 12,
            bottom: MediaQuery.of(context).padding.bottom + 16,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(48),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 8.0, sigmaY: 8.0),
                child: Container(
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.8),
                    borderRadius: BorderRadius.circular(48),
                    border: Border.all(
                      color: AppColors.grey200.withOpacity(0.8),
                      width: 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      // 카메라 버튼
                      Padding(
                        padding: const EdgeInsets.only(left: 12),
                        child: GestureDetector(
                          onTap: _handleCameraButton,
                          child: Image.asset(
                            'assets/icons/functions/camera.png',
                            width: 24,
                            height: 24,
                          ),
                        ),
                      ),

                      const SizedBox(width: 12),

                      // 텍스트 입력 필드
                      Expanded(
                        child: TextField(
                          controller: _messageController,
                          focusNode: _textFieldFocusNode,
                          decoration: InputDecoration(
                            hintText: '무엇이든 이야기하세요',
                            hintStyle: AppTypography.b4.withColor(AppColors.grey400),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(
                              vertical: 14,
                            ),
                          ),
                          onSubmitted: (_) => _sendCurrentMessage(),
                          maxLines: null,
                        ),
                      ),

                      const SizedBox(width: 12),

                      // 동적 버튼 (음성/전송)
                      _buildDynamicButton(),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 🆕 오디오 처리 인디케이터 추가
  Widget _buildAudioProcessingIndicator() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: AppColors.main100,
            borderRadius: const BorderRadius.only(
              topLeft: Radius.zero,
              topRight: Radius.circular(16),
              bottomLeft: Radius.circular(16),
              bottomRight: Radius.circular(16),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '🧠 스마트 음성 분석 중',
                style: AppTypography.b3.withColor(AppColors.main700),
              ),
              const SizedBox(width: 8),
              const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation<Color>(AppColors.main700),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMessageList() {
    // null 체크 및 유효성 검사 추가
    if (_currentConversationId == null || _currentConversationId!.isEmpty) {
      print('Invalid conversation ID: $_currentConversationId');
      return _buildEmptyState();
    }

    final conversationService = ref.watch(conversationServiceProvider);
    return StreamBuilder<List<Message>>(
      stream: conversationService.getConversationMessages(_currentConversationId!),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        // 더 상세한 에러 처리 추가
        if (snapshot.hasError) {
          print('Error loading messages: ${snapshot.error}');
          final error = ErrorHandler.handleException(snapshot.error!);
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SvgPicture.asset( // Changed to SvgPicture
                  'assets/icons/functions/icon_info.svg', // Assuming an error_outline SVG exists
                  width: 48,
                  height: 48,
                  colorFilter: ColorFilter.mode(AppColors.grey400, BlendMode.srcIn),
                ),
                const SizedBox(height: 16),
                Text(
                  '메시지를 불러올 수 없습니다',
                  style: AppTypography.b2.withColor(AppColors.grey600),
                ),
                const SizedBox(height: 8),
                Text(
                  error.message,
                  style: AppTypography.c2.withColor(AppColors.grey400),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.grey200,
                        foregroundColor: AppColors.grey600,
                      ),
                      child: Text('돌아가기'),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {}); // 스트림 재시도
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.main600,
                        foregroundColor: Colors.white,
                      ),
                      child: Text('다시 시도'),
                    ),
                  ],
                ),
              ],
            ),
          );
        }

        final messages = snapshot.data ?? [];

        if (messages.isEmpty) {
          return _buildEmptyState();
        }

        // 메시지 순서를 뒤집어서 최신 메시지가 아래에 오도록
        final reversedMessages = messages.reversed.toList();

        return ListView.builder(
          controller: _scrollController,
          reverse: true, // ListView를 뒤집어서 아래부터 시작
          padding: const EdgeInsets.fromLTRB(12, 82, 12, 82), // 패딩도 뒤집음
          itemCount: reversedMessages.length,
          itemBuilder: (context, index) {
            final message = reversedMessages[index];

            // AI의 마지막 메시지인지 확인
            final isLastAiMessage = index == 0 && !message.isUser;

            return _buildMessageBubble(message, isLastAiMessage);
          },
        );
      },
    );
  }

  Widget _buildMessageBubble(Message message, [bool isLastAiMessage = false]) {
    final isUser = message.isUser;

    return Column(
      crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        // AI의 마지막 메시지일 때만 아이콘 표시
        if (isLastAiMessage)
          Container(
            child: Row(
              children: [
                SvgPicture.asset(
                  'assets/images/logos/tiiun_logo.svg',
                  width: 20,
                  height: 20,
                ),
              ],
            ),
          ),

        // 메시지 버블
        Align(
          alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 8),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            constraints: BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width * 0.8,
            ),
            decoration: BoxDecoration(
              color: isUser ? AppColors.main100 : AppColors.grey50,
              borderRadius: isUser
                  ? const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.zero,
                bottomLeft: Radius.circular(16),
                bottomRight: Radius.circular(16),
              )
                  : const BorderRadius.only(
                topLeft: Radius.zero,
                topRight: Radius.circular(16),
                bottomLeft: Radius.circular(16),
                bottomRight: Radius.circular(16),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 이미지 메시지 처리
                if (message.type == MessageType.image && message.attachments.isNotEmpty)
                  _buildImageMessage(message.attachments.first.url),
                // 텍스트 메시지 처리 (이미지가 없거나 텍스트가 있는 경우)
                if (message.content.isNotEmpty)
                  Padding(
                    padding: EdgeInsets.only(
                      top: (message.type == MessageType.image && message.attachments.isNotEmpty) ? 8 : 0,
                    ),
                    child: Text(
                      message.content,
                      style: AppTypography.b3.withColor(
                        isUser ? AppColors.grey800 : AppColors.grey900,
                      ),
                    ),
                  ),
                if (message.audioUrl != null && message.audioUrl!.isNotEmpty) // 오디오 URL이 있으면 재생 버튼 추가
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: _buildAudioPlayer(message.audioUrl!), // 오디오 플레이어 빌드 메서드 호출
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // 오디오 플레이어 위젯 추가
  Widget _buildAudioPlayer(String audioUrl) {
    final voiceService = ref.read(voiceServiceProvider); // VoiceService 인스턴스 가져오기
    return StreamBuilder<bool>(
      stream: Stream.periodic(const Duration(milliseconds: 100), (_) => voiceService.isPlaying && voiceService.currentPlayingUrl == audioUrl), // 재생 상태 스트림
      builder: (context, snapshot) {
        final isPlayingThisAudio = snapshot.data ?? false;
        return GestureDetector(
          onTap: () async {
            if (isPlayingThisAudio) {
              await voiceService.stopSpeaking(); // 재생 중이면 중지
            } else {
              await voiceService.playAudio(audioUrl, isLocalFile: audioUrl.startsWith('/data')); // 재생 시작
            }
          },
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                isPlayingThisAudio ? Icons.pause_circle_filled : Icons.play_circle_fill,
                color: AppColors.main700,
                size: 24,
              ),
              const SizedBox(width: 8),
              Text(
                isPlayingThisAudio ? '재생 중' : '음성 메시지',
                style: AppTypography.b4.withColor(AppColors.main700),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTypingIndicator() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: const BoxDecoration(
            color: AppColors.grey50,
            borderRadius: BorderRadius.only(
              topLeft: Radius.zero,
              topRight: Radius.circular(16),
              bottomLeft: Radius.circular(16),
              bottomRight: Radius.circular(16),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '입력 중',
                style: AppTypography.b3.withColor(AppColors.grey900),
              ),
              const SizedBox(width: 8),
              const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation<Color>(AppColors.grey900),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.chat_bubble_outline,
            size: 64,
            color: AppColors.grey300,
          ),
          SizedBox(height: 16),
          Text(
            '새로운 대화를 시작해보세요!',
            style: TextStyle(color: AppColors.grey600, fontSize: 16),
          ),
        ],
      ),
    );
  }

  // 메시지 입력 부분에서 동적 버튼만 ValueListenableBuilder로 감싸기
  Widget _buildDynamicButton() {
    return ValueListenableBuilder<bool>(
      valueListenable: _hasTextNotifier,
      builder: (context, hasText, child) {
        return Padding(
          padding: const EdgeInsets.only(right: 12),
          child: GestureDetector(
            onTap: () {
              if (hasText) {
                _sendCurrentMessage();
              } else {
                _toggleVoiceInput();
              }
            },
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 150),
              transitionBuilder: (Widget child, Animation<double> animation) {
                return FadeTransition(
                  opacity: animation,
                  child: child,
                );
              },
              child: hasText
                  ? SvgPicture.asset(
                'assets/icons/functions/Paper_Plane.svg',
                width: 28,
                height: 28,
                colorFilter: const ColorFilter.mode(AppColors.main600, BlendMode.srcIn),
                key: const ValueKey('send'),
              )
                  : ValueListenableBuilder<bool>(
                valueListenable: _isRecordingNotifier,
                builder: (context, isRecording, child) {
                  return SvgPicture.asset(
                    'assets/icons/functions/voice.svg',
                    width: 28,
                    height: 28,
                    key: ValueKey(isRecording ? 'voice_recording' : 'voice'),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  // 🚀 🆕 개선된 음성 입력 - GPT-4o Audio Service 사용
  Future<void> _toggleVoiceInput() async {
    if (_isRecordingNotifier.value) {
      // 녹음 중지 및 처리
      await _stopRecordingAndProcess();
    } else {
      // 녹음 시작
      await _startRecording();
    }
  }

  // 🎙️ 녹음 시작
  Future<void> _startRecording() async {
    try {
      // 권한 확인
      if (!await _audioRecorder.hasPermission()) {
        _showSnackBar('마이크 권한이 필요합니다.', AppColors.point900);
        return;
      }

      // 임시 디렉토리에 녹음 파일 저장
      final tempDir = await getTemporaryDirectory();
      _currentRecordingPath = '${tempDir.path}/${_uuid.v4()}.m4a';

      // 녹음 설정
      const recordConfig = record_pkg.RecordConfig(
        encoder: record_pkg.AudioEncoder.aacLc,
        bitRate: 128000,
        sampleRate: 44100,
        numChannels: 1,
      );

      // 녹음 시작
      await _audioRecorder.start(recordConfig, path: _currentRecordingPath!);
      
      _isRecordingNotifier.value = true;
      _currentTranscriptionNotifier.value = '🎙️ 말씀하세요...';
      
      // 입력 필드 초기화
      _messageController.clear();
      _hasTextNotifier.value = false;
      _textFieldFocusNode.unfocus();

      _showSnackBar('🧠 스마트 음성 대화 모드 시작', AppColors.main600);
      
    } catch (e) {
      _showSnackBar('녹음 시작 중 오류가 발생했습니다: ${e.toString()}', AppColors.point900);
      _isRecordingNotifier.value = false;
    }
  }

  // 🛑 녹음 중지 및 GPT-4o 처리
  Future<void> _stopRecordingAndProcess() async {
    try {
      _isRecordingNotifier.value = false;
      _currentTranscriptionNotifier.value = '';

      // 녹음 중지
      final recordPath = await _audioRecorder.stop();
      if (recordPath == null || recordPath.isEmpty) {
        _showSnackBar('녹음 파일을 찾을 수 없습니다.', AppColors.point900);
        return;
      }

      // 처리 중 인디케이터 시작
      _isProcessingAudioNotifier.value = true;

      // 🚀 GPT-4o Audio Service 사용
      final gpt4oService = ref.read(gpt4oAudioServiceProvider);
      
      // 대화 기록 가져오기 (최근 5개)
      final conversationHistory = await _getRecentConversationHistory();

      // GPT-4o Audio로 음성 대화 처리
      final result = await gpt4oService.processAudioConversation(
        audioFilePath: recordPath,
        systemPrompt: '''
당신은 "틔운이"라는 친근하고 공감적인 AI 상담사입니다.
사용자의 음성 톤과 감정을 이해하고, 자연스럽고 따뜻한 음성으로 응답하세요.

특별 지침:
- 사용자의 음성에서 감정을 파악하여 적절히 반응하세요
- 자연스럽고 대화체로 응답하세요
- 음성으로 듣기 편한 적당한 길이로 응답하세요
- 공감과 이해를 바탕으로 따뜻하게 대화하세요
''',
        conversationHistory: conversationHistory,
        voiceStyle: 'nova', // 친근한 여성 목소리
      );

      // 대화 ID 생성 (없는 경우)
      if (_currentConversationId == null) {
        final conversationService = ref.read(conversationServiceProvider);
        final userTranscription = result['userTranscription'] as String;
        final newConversation = await conversationService.createConversation(
          title: userTranscription.length > 20 
              ? '${userTranscription.substring(0, 20)}...' 
              : userTranscription,
          agentId: 'gpt4o_audio_agent',
        );
        _currentConversationId = newConversation.id;
      }

      // 사용자 메시지 추가 (음성 인식 결과)
      await ref.read(conversationServiceProvider).addMessage(
        conversationId: _currentConversationId!,
        content: result['userTranscription'] as String,
        sender: MessageSender.user,
        type: MessageType.text,
      );

      // AI 응답 메시지 추가 (텍스트 + 오디오)
      await ref.read(conversationServiceProvider).addMessage(
        conversationId: _currentConversationId!,
        content: result['responseText'] as String,
        sender: MessageSender.agent,
        audioUrl: result['responseAudioPath'] as String?,
        type: MessageType.audio,
      );

      // 🔊 자동으로 응답 음성 재생
      final responseAudioPath = result['responseAudioPath'] as String?;
      if (responseAudioPath != null && responseAudioPath.isNotEmpty) {
        final voiceService = ref.read(voiceServiceProvider);
        await voiceService.playAudio(responseAudioPath, isLocalFile: true);
      }

      _scrollToBottom();
      _showSnackBar('🎉 스마트 음성 대화 완료!', AppColors.main600);

    } catch (e) {
      _showSnackBar('음성 처리 중 오류가 발생했습니다: ${e.toString()}', AppColors.point900);
      
      // 🔄 폴백: 기존 방식으로 대체
      try {
        _showSnackBar('기본 음성 인식으로 전환합니다...', AppColors.grey600);
        await _fallbackToBasicVoiceRecognition();
      } catch (fallbackError) {
        _showSnackBar('음성 인식에 실패했습니다.', AppColors.point900);
      }
    } finally {
      _isProcessingAudioNotifier.value = false;
      
      // 임시 파일 정리
      if (_currentRecordingPath != null) {
        try {
          final file = File(_currentRecordingPath!);
          if (await file.exists()) {
            await file.delete();
          }
        } catch (e) {
          debugPrint('임시 파일 삭제 실패: $e');
        }
        _currentRecordingPath = null;
      }
    }
  }

  // 📚 최근 대화 기록 가져오기 (GPT-4o 컨텍스트용)
  Future<List<Map<String, dynamic>>> _getRecentConversationHistory() async {
    if (_currentConversationId == null) return [];
    
    try {
      final conversationService = ref.read(conversationServiceProvider);
      final messages = await conversationService.getConversationMessages(_currentConversationId!).first;
      
      // 최근 10개 메시지만 가져와서 GPT-4o 형식으로 변환
      return messages
          .take(10)
          .map((message) => {
                'role': message.isUser ? 'user' : 'assistant',
                'content': message.content,
              })
          .toList();
          
    } catch (e) {
      debugPrint('대화 기록 가져오기 실패: $e');
      return [];
    }
  }

  // 🔄 폴백: 기본 음성 인식 사용
  Future<void> _fallbackToBasicVoiceRecognition() async {
    if (_currentRecordingPath == null) return;
    
    // 기존 VoiceAssistantService 사용해서 간단한 텍스트 변환
    final voiceAssistantService = ref.read(voiceAssistantServiceProvider);
    // 여기서는 간단하게 기본 안내 메시지만 표시
    _showSnackBar('기본 음성 인식 기능을 사용해주세요.', AppColors.grey600);
  }

  void _sendCurrentMessage() {
    final message = _messageController.text.trim();
    if (message.isNotEmpty) {
      // 메시지 전송 전에 먼저 스크롤 위치 유지
      final currentScrollOffset = _scrollController.hasClients ? _scrollController.offset : 0.0;

      _sendMessage(message);
      _messageController.clear();

      // 텍스트 클리어 후 스크롤 위치 복원
      if (_scrollController.hasClients) {
        _scrollController.jumpTo(currentScrollOffset);
      }
    }
  }

  Future<void> _sendMessage(String message) async {
    if (_isLoading || _isTyping) return;

    setState(() {
      _isLoading = true;
    });

    final conversationService = ref.read(conversationServiceProvider);
    final aiService = ref.read(aiServiceProvider);

    try {
      if (_currentConversationId == null) {
        final newConversation = await conversationService.createConversation(
          title: message.length > 20 ? message.substring(0, 20) + '...' : message,
          agentId: 'default_agent',
        );
        _currentConversationId = newConversation.id;
      }

      await conversationService.addMessage(
        conversationId: _currentConversationId!,
        content: message,
        sender: MessageSender.user,
      );

      setState(() {
        _isTyping = true;
        _isLoading = false;
      });

      // Give some visual feedback before AI starts processing
      await Future.delayed(const Duration(milliseconds: 500));

      final aiResponse = await aiService.getResponse(
        conversationId: _currentConversationId!,
        userMessage: message,
      );

      await conversationService.addMessage(
        conversationId: _currentConversationId!,
        content: aiResponse.text,
        sender: MessageSender.agent,
        audioUrl: aiResponse.voiceFileUrl,
        audioDuration: aiResponse.voiceDuration?.toInt(),
        type: MessageType.audio, // Agent's message might be audio
      );

      _scrollToBottom();
    } on AppError catch (e) {
      print('AppError during message sending: ${e.message}');
      _showSnackBar('메시지 전송 중 오류가 발생했습니다: ${e.message}', AppColors.point900);
    } catch (e, stackTrace) {
      print('Unexpected error during message sending: $e');
      _showSnackBar('메시지 전송 중 알 수 없는 오류가 발생했습니다.', AppColors.point900);
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _isTyping = false;
        });
      }
    }
  }

  // reverse ListView에서는 0이 맨 아래
  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients && mounted) {
        _scrollController.animateTo(
          0.0, // reverse ListView에서는 0이 맨 아래
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // 텍스트 변경 감지
  void _onTextChanged() {
    final hasText = _messageController.text.trim().isNotEmpty;
    _hasTextNotifier.value = hasText;
  }

  // 키보드 포커스 주기
  void _focusTextField() {
    FocusScope.of(context).requestFocus(_textFieldFocusNode);
  }

  void _showSnackBar(String message, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
      ),
    );
  }

  // 이미지 메시지 위젯
  Widget _buildImageMessage(String imageUrl) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: CachedNetworkImage(
        imageUrl: imageUrl,
        width: double.infinity,
        fit: BoxFit.cover,
        placeholder: (context, url) => Container(
          height: 200,
          color: AppColors.grey100,
          child: Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(AppColors.main600),
            ),
          ),
        ),
        errorWidget: (context, url, error) => Container(
          height: 200,
          color: AppColors.grey100,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.error_outline, color: AppColors.grey400, size: 32),
              const SizedBox(height: 8),
              Text(
                '이미지를 불러올 수 없습니다',
                style: AppTypography.c2.withColor(AppColors.grey400),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // 카메라 버튼 핸들러
  Future<void> _handleCameraButton() async {
    try {
      if (_currentConversationId == null) {
        _showSnackBar('대화를 시작한 후에 이미지를 보낼 수 있습니다.', AppColors.grey600);
        return;
      }

      final imageService = ref.read(imageServiceProvider);
      
      // 이미지 소스 선택 다이얼로그 표시
      ImageSource? source = await imageService.showImageSourceDialog(context);
      if (source == null) return; // 사용자가 취소함

      _isUploadingImageNotifier.value = true;

      // 이미지 선택 및 업로드
      String? imageUrl = await imageService.pickAndUploadImage(
        source: source,
        conversationId: _currentConversationId!,
        context: context,
      );

      if (imageUrl != null) {
        await _sendImageMessage(imageUrl);
        _showSnackBar('이미지가 전송되었습니다.', AppColors.main600);
      }
    } catch (e) {
      _showSnackBar('이미지 전송 중 오류가 발생했습니다: ${e.toString()}', AppColors.point900);
    } finally {
      _isUploadingImageNotifier.value = false;
    }
  }

  // 이미지 메시지 전송
  Future<void> _sendImageMessage(String imageUrl) async {
    if (_isLoading || _isTyping) return;

    setState(() {
      _isLoading = true;
    });

    final conversationService = ref.read(conversationServiceProvider);

    try {
      if (_currentConversationId == null) {
        final newConversation = await conversationService.createConversation(
          title: '이미지 대화',
          agentId: 'default_agent',
        );
        _currentConversationId = newConversation.id;
      }

      // 이미지 메시지 추가
      await conversationService.addMessage(
        conversationId: _currentConversationId!,
        content: '이미지를 보냈습니다.',
        sender: MessageSender.user,
        type: MessageType.image,
        attachments: [
          MessageAttachment(
            url: imageUrl,
            type: 'image',
            fileName: 'image.jpg',
          ),
        ],
      );

      _scrollToBottom();
    } on AppError catch (e) {
      print('AppError during image message sending: ${e.message}');
      _showSnackBar('이미지 전송 중 오류가 발생했습니다: ${e.message}', AppColors.point900);
    } catch (e, stackTrace) {
      print('Unexpected error during image message sending: $e');
      _showSnackBar('이미지 전송 중 알 수 없는 오류가 발생했습니다.', AppColors.point900);
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  // Modal Bottom Sheet로 분석 화면 띄우기
  void _showAnalysisModal() {
    if (_currentConversationId != null) {
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        barrierColor: Colors.black.withOpacity(0.5),
        builder: (context) => ModalAnalysisScreen(
          conversationId: _currentConversationId!,
        ),
      );
    } else {
      _showSnackBar('대화가 시작된 후에 분석을 시작할 수 있습니다.', AppColors.main600);
    }
  }
}